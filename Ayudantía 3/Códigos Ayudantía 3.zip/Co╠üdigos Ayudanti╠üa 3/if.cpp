#include <iostream>
using namespace std;

int main(){
    int numero;
    cout << "Su numero es igual a 420?" << endl;
    cin >> numero;
    if(numero==420){
        cout << "Felicitaciones! su numero es 420, qué suerte. " << endl;
    }
    else{
        cout << "Lo sentimos... su numero no es 420... qué tristeza. " << endl;
    }
}


